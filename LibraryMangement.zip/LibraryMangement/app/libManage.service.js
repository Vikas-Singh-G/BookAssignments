libApp.service("libManage",function(){

    this.engDetails=[
            {bookId:'MS102', bookImage:"image/EngBook/MS_book.jpg", bookName:'Manufacturing Engineering',bookAuthor:'j.Paul Davim',isbnCode:'12343625952',bookDescp:'This book aims to provide research and review studies on manufacturing engineering. This research book can be used for final undergraduate engineering courses (for example, mechanical, manufacturing, industrial, etc) or as a subject on manufacturing at the postgraduate level. Also, this book can serve as a useful reference for academics, manufacturing researchers, mechanical manufacturing and industrial engineers, and professionals in related industries with manufacturing engineering.',price:"$205"},
            {bookId:'CS602', bookImage:"image/EngBook/C_ShBook.png", bookName:'Advanced C#',bookAuthor:'Paul Kimmel',isbnCode:'43637892467',bookDescp:'The Roommate by Rosie Danan follows Clara, an uptight and a little bit awkward East Coaster who moves to LA to pursue her longtime crush — except when he is actually out on tour with his band, she winds up living with Josh. These two clash in personalities and they are very unlikely roommates. ',price:'$123'},
              ];

    this.romDetails=[
            
            {bookId:'RM204', bookImage:'image/RomBook/TheR_M.jpg', bookName:'The Roommate ',bookAuthor:'Rosie Danan',isbnCode:'12345678901',bookDescp:'The Roommate by Rosie Danan follows Clara, an uptight and a little bit awkward East Coaster who moves to LA to pursue her longtime crush — except when he is actually out on tour with his band, she winds up living with Josh',price:'$30'},
            {bookId:'MO204', bookImage:'image/RomBook/MapOfStar.jpg', bookName:'Map Of Star',bookAuthor:'Catherine Law',isbnCode:'76906433576',bookDescp:'Map of Stars is a fantastic book about a strong woman who\'s married to her best friend. ',price:'$25.9'},
            {bookId:'PD306', bookImage:'', bookName:'NA',bookAuthor:'NA',isbnCode:'NA',bookDescp:'NA',price:'NA'}
                ];
    this.devDetails=[
    {bookId:'RM901', bookImage:'image/DevBook/Ramayan.jpg', bookName:'Shri Ramcharit Manas Ramayan',bookAuthor:'Shri Goswami Tulsidas ji Maharaj',isbnCode:'',bookDescp:'Shri Ramcharit Manas Ramayan (All 8 Kands ) In Hindi With Valvet Book Cover Shree Ramacharitmanas, bestowed by Shri Goswami Tulsidas ji Maharaj, is the masterpiece of Hindi literature. This is the unique posture of the ideal ideology of ideal religion, ideal household life, ideal family life, etc.',price:'$500'},
    {bookId:'MB101', bookImage:'image/DevBook/Bhagavad_Gita.jpg', bookName:'Shrimad Bhagavad Gita',bookAuthor:'Ved Vyasa',isbnCode:'',bookDescp:'Life and LoveHope and Happiness Yoga and Spiritualit Soul and Mind,God & Eternity  & Much more as you go on reading…..',price:'400'},
              ];

    this.getEngbookDetails=function()
    {
        return this.engDetails;
    }
    this.getRombookDetails=function()
    {
        return this.romDetails;
    }
    this.getDevbookDetails=function()
    {
        return this.devDetails;
    }


    this.addEngBook=function(newBook)
    {
        //console.log("Engineering Book Details to be added ",newBook);
        this.engDetails.push(newBook);
    }
    this.addRomBook=function(newBook)
    {
       // console.log("Romantic Book Details to be added ",newBook);
        this.romDetails.push(newBook);
    }
    this.addDevBook=function(newBook)
    {
       // console.log("Devotional Book Details to be added ",newBook);
        this.devDetails.push(newBook);
    }
   
    this.deleteEngBook=function(lib)
    {
        var pos=this.engDetails.findIndex(item=> 
            {
            if(item.bookId == lib.bookId)
            {
                return true;
            }
            else
            {
                return false;
            }
            })  
        this.engDetails.splice(pos,1);
    }

    this.deleteRomBook=function(lib)
    {
        var pos=this.romDetails.findIndex(item=> 
            {
            if(item.bookId == lib.bookId)
            {
                return true;
            }
            else
            {
                return false;
            }
            })  
        this.romDetails.splice(pos,1);
    }
    this.deleteDevBook=function(lib)
    {
        var pos=this.devDetails.findIndex(item=> 
            {
            if(item.bookId == lib.bookId)
            {
                return true;
            }
            else
            {
                return false;
            }
            })  
        this.devDetails.splice(pos,1);
    }


    //================Below line Left for some modifications
    // this.addNewBooks=[ {engineeringBook:this.addEngBook, romanticBook:this.addRomBook, devotionalBook:this.addDevBook}]




})