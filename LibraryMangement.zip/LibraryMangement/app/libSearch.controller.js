libApp.controller("libSearchController",function($scope,libManage){
    $scope.libSearchEngArr=libManage.getEngbookDetails();
    $scope.libSearchRomArr=libManage.getRombookDetails();
    $scope.libSearchDevArr=libManage.getDevbookDetails();
    $scope.deleteEngBookEventHandler=function(libToBeDeleted)
    {
        libManage.deleteEngBook(libToBeDeleted);
       
    }
    $scope.deleteRomBookEventHandler=function(libToBeDeleted)
    {
        libManage.deleteRomBook(libToBeDeleted);
       
    }

    $scope.deleteDevBookEventHandler=function(libToBeDeleted)
    {
        libManage.deleteDevBook(libToBeDeleted);
       
    }


    
        
})