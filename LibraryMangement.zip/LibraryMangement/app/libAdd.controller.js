libApp.controller("libAddController",function($scope,libManage){
    
    
    $scope.editLibraryDetailsEventHandler=function(obj){
        $scope.selectedBook=obj;
        
    }
    
    $scope.saveEngBookDetailsEventHandler=function(){
        libManage.addEngBook($scope.newBook)
    }

    $scope.saveRomBookDetailsEventHandler=function(){
        libManage.addRomBook($scope.newBook)
    }
    
    $scope.saveDevBookDetailsEventHandler=function(){
        libManage.addDevBook($scope.newBook)
    }
                /* ============  left For Some Modification==============
                $scope.selectedBookType={};
                $scope.saveBookDetailEventHandler=function(obj){
                    $scope.selectedBookType=obj;
                    confirm("U have selected Book  :"+ obj.selectedBookType +" section to add new book");
                    
                } */
})