﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace LibraryManagements
{
    class Book
        {
            public int bookId;
            public string bookName;
            public string authorName;
            public string bookDescp;
            public int isbnCode;
            public double price;
            public int quantity;

            public Book()
            {
            }

            public Book(int bookId, string bookName, string authorName, string bookDescp, int isbnCode, double price)
            {
                this.bookId = bookId;
                this.bookName = bookName;
                this.authorName = authorName;
                this.bookDescp = bookDescp;
                this.isbnCode = isbnCode;
                this.price = price;
            }

            static List<Book> bookDetail = new List<Book>();
            static void Main(string[] args)
            {
                Int32 option1 = DisplayMainMenu();
                MainCall(option1);
                Console.Read();
            }

            private static void MainCall(Int32 option)
            {
                Int32 result = 0;
                Int32 bookId1 = 0;
                switch (option)
                {
                    case 1:
                        AddBook();
                        break;
                    case 2:
                        DisplayList();
                        Int32 option1 = DisplayMainMenu();
                        MainCall(option1);
                        break;
                    case 3:
                        Console.WriteLine("Enter bookId which you want to update:");
                        bookId1 = Convert.ToInt32(Console.ReadLine());
                        result = update(bookId1);
                        break;
                    case 4:
                        Console.WriteLine("Enter bookId which you want to delete:");
                        bookId1 = Convert.ToInt32(Console.ReadLine());
                        result = DeleteBook(bookId1);
                        if (result == 1)
                            Console.WriteLine("Book deleted");
                        else
                            Console.WriteLine("Book with ID:" + bookId1 + " not found");
                        option1 = DisplayMainMenu();
                        MainCall(option1);
                        break;
                    case 5:
                        Console.WriteLine("THANKS for Visit");
                        break;
                    default:
                        Console.WriteLine("Invalid Input");
                        option1 = DisplayMainMenu();
                        MainCall(option1);
                        break;
                }
            }

            private static int DisplayMainMenu()
            {
                Console.WriteLine("\nSelect any option:");
                Console.WriteLine("1. Add Book");
                Console.WriteLine("2. Display Book");
                Console.WriteLine("3. Edit Book");
                Console.WriteLine("4. Delete Book");
                Console.WriteLine("5. Exit");

                Int32 option = 0;
                try
                {
                    option = Convert.ToInt32(Console.ReadLine());
                }
                catch (Exception)
                {
                    Console.WriteLine("Some Error Occured");
                }
                return option;
            }

            private static List<Book> AddBook()
            {
                Book book = new Book();
                try
                {
                    Console.WriteLine("Enter following information to add new Book:");
                    Console.WriteLine("Enter Book Name");
                    book.bookName = Console.ReadLine();
                    Console.WriteLine("Enter Author Name");
                    book.authorName = Console.ReadLine();
                    Console.WriteLine("Enter Book ID (Only Numeric)");
                    book.bookId = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter ISBN number(Only Numeric)");
                    book.isbnCode = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Book Price:");
                    book.price = Convert.ToInt64(Console.ReadLine());
                    if (bookDetail.Count > 0)
                    {
                        if (bookDetail.Exists(Book => book.bookId == book.bookId))
                        {
                            Console.WriteLine("Book already exists with id:" + book.bookId);
                        }
                        else
                        {
                            bookDetail.Add(book);
                        }
                    }
                    else
                    {
                        bookDetail.Add(book);
                        Console.WriteLine("Book successfully Added");
                    }
                    Console.WriteLine(@"Do you want to add more Book? Y\N");
                    char choice = Console.ReadKey().KeyChar;
                    switch (Char.ToUpper(choice))
                    {
                        case 'Y':
                            AddBook();
                            break;
                        case 'N':
                            Int32 option1 = DisplayMainMenu();
                            MainCall(option1);
                            break;
                        default:
                            Console.WriteLine("Please select right option");
                            Console.WriteLine("-----------------------------------------------");
                            option1 = DisplayMainMenu();
                            MainCall(option1);
                            break;

                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("Please select right option");
                    Console.WriteLine("-----------------------------------------------");
                    Int32 option1 = DisplayMainMenu();
                    MainCall(option1);
                }
                return bookDetail;
            }

            private static void DisplayList()
            {
                Console.WriteLine("");
                Console.WriteLine("Book Details");
                foreach (Book book in bookDetail)
                {
                    Console.WriteLine("Book ID:" + book.bookId + " Book Name:" + book.bookName + " Author Name:" + book.authorName + " ISBN number:" + book.isbnCode + " Book Price:" + book.price);
                }
            }

            private static Int32 update(Int32 bookId)
            {
                Int32 result = 0;
                Book book = new Book();
                try
                {
                    var bookinfo = bookDetail.Where(e => e.bookId == bookId).FirstOrDefault();
                    if (bookinfo != null)
                    {
                        Console.WriteLine("Enter Book Name");
                        book.bookName = Console.ReadLine();
                        Console.WriteLine("Enter Author Name");
                        book.authorName = Console.ReadLine();
                        Console.WriteLine("Enter ISBN number(Only Numeric)");
                        book.isbnCode = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Book Price:");
                        book.price = Convert.ToInt64(Console.ReadLine());
                        bookDetail.Where(e => e.bookId == bookId).FirstOrDefault().bookName = book.bookName;
                        bookDetail.Where(e => e.bookId == bookId).FirstOrDefault().authorName = book.authorName;
                        bookDetail.Where(e => e.bookId == bookId).FirstOrDefault().isbnCode = book.isbnCode;
                        bookDetail.Where(e => e.bookId == bookId).FirstOrDefault().price = book.price;
                        Console.WriteLine("Book with id:" + bookId + "updated successfully");
                        Int32 option1 = DisplayMainMenu();
                        MainCall(option1);
                    }
                    else
                    {
                        Console.WriteLine("Book with id:" + bookId + "does not exist");
                        Int32 option1 = DisplayMainMenu();
                        MainCall(option1);
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("Please select right option");
                    Console.WriteLine("-----------------------------------------------");
                    Int32 option1 = DisplayMainMenu();
                    MainCall(option1);
                }
                return result;
            }

            private static int DeleteBook(Int32 bookId)
            {
                Int32 result = bookDetail.RemoveAll(e => e.bookId == bookId);
                return result;
            }
        }
    }