﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace LibraryManagements
{
    //Defining a class Book
    class Book
    {
        public int bookId;
        public string bookName;
        public string authorName;
        public string bookDescp;
        public double isbnCode;
        public int bookPrice;
        public int quantity;
        public int x=0;
        public Book()
        {

        }

        public Book(int bookId, string bookName, string authorName, string bookDescp, double isbnCode, int bookPrice, int quantity)
        {
            this.bookId = bookId;
            this.bookName = bookName;
            this.authorName = authorName;
            this.bookDescp = bookDescp;
            this.isbnCode = isbnCode;
            this.bookPrice = bookPrice;
            this.quantity = quantity;
        }

        public override string ToString()
        {
            return $"Product Id : {bookId}; Product Name : {bookName};Author name:{authorName};Book Description:{bookDescp}; Price:{bookPrice}; Quantity:{quantity}";
        }
    }
    
    class Program
    {
        static List<Book> bookList = new List<Book>();
        //static List<BorrowDetails> borrowList = new List<BorrowDetails>();
        static Book book = new Book();
       

        //Password verfication and Menu 
        static void Main(string[] args)
        {
            Console.Write("Welcome !!!\nEnter your password :");
            string password = Console.ReadLine();

            if (password == "admin")
            {
                bool close = true;
                while (close)
                {
                    Console.WriteLine("\nMenu\n" +
                    "1)Add book\n" +
                    "2)Delete book\n" +
                    "3)Edit book details\n" +
                    "4)Close\n\n");
                    Console.Write("Choose your option from menu :");

                    int option = Convert.ToInt32(Console.ReadLine());

                    if (option == 1)
                    {
                        AddBook();
                    }
                    //else if (option == 2)
                    //{
                    //    RemoveBook();
                    //}
                    else if (option == 3)
                    {
                        EditBook();
                    }
              
                    else if (option == 4)
                    {
                        Console.WriteLine("Thank you");
                        close = false;
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Invalid option\nRetry !!!");
                    }
                }
            }
            else
            {
                Console.WriteLine("Invalid password");
            }
            Console.ReadLine();
        }

        //To add book details to the Library database
        public static void AddBook()
        {
                Book book = new Book();
            List<Book> bookList = new List<Book>{ };
               
           
            Console.WriteLine("Book Id:");
            book.bookId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Book Name:");
            book.bookName = Console.ReadLine();
            Console.Write("Author Name:");
            book.authorName = Console.ReadLine();
            Console.Write("ISBN Code:");
            book.isbnCode = Convert.ToInt32(Console.ReadLine());
            Console.Write("Book Price:");
            book.bookPrice = int.Parse(Console.ReadLine());
            Console.Write("Number of Books:");
           // book.x =
            book.quantity = int.Parse(Console.ReadLine());
            bookList.Add(book);
        }

        //To delete book details from the Library database 
        public static void RemoveBook()
        {
            Book book = new Book();
            List<Book> bookList = new List<Book>{};
            Console.Write("Enter Book id to be deleted : ");

            int Del = Convert.ToInt32(Console.ReadLine());

            if (bookList.Exists(x => x.bookId == Del))
            {
                //book.bookId.RemoveAll(book.bookId);//RemoveAt//(Del - 1);
                Console.WriteLine("Book id - {0} has been deleted", Del);
            }
            else
            {
                Console.WriteLine("Invalid Book id");
            }

            bookList.Add(book);
        }

        //To search book details from the Library database using Book id 
        public static void EditBook()
        {
            //Book book = new Book();
            Console.Write("Search by BOOK id :");
           int find = Convert.ToInt32(Console.ReadLine());

            if (bookList.Exists(x => x.bookId == find))
            {
                foreach (Book searchId in bookList)
                {
                    if (searchId.bookId == find)
                    {
                        Console.WriteLine("Book id :{0}\n" +
                        "Book name :{1}\n" +
                        "Book price :{2}\n" +
                        "Book Count :{3}", searchId.bookId, searchId.bookName, searchId.bookPrice, searchId.quantity);
                    }
                }
            }
            else
            {
                Console.WriteLine("Book id {0} not found", find);
            }
        }

        

        
    }
}